public class Main {
	public static void main(String[] args) {
        Calculadora c = new Calculadora (4,5);
        c.soma();
        c.mostraResultado ();
        c.produto();
        c.mostraResultado();
	}
}